const quizData = [
    { question: "Which of the following is Santa's reindeer?", answers: ['Comet', 'Lander', 'Blixem'], correct: 0 },
    { question: 'The 25th of December was originally a Roman holiday to what God?', answers: ['Zeus', 'Poseidon', 'The Sun God'], correct: 2 },
    { question: 'Children in what country refer to Santa Claus as Babbo Natale?', answers: ['France', 'Italy', 'Spain'], correct: 1 },
    { question: 'In what country did the tradition of putting up a Christmas tree begin?', answers: ['Germany', 'England', 'Canada'], correct: 0 },
    { question: 'Donald Trump appears in which Home Alone Movie?', answers: ['Home Alone 2', 'Home Alone 3', 'Home Alone 4'], correct: 0 }
];

const startScreen = document.querySelector('.start-info');
const inGameScreen = document.querySelector('.in-game-info');
const startButton = document.getElementById('start-btn');
const questionText = document.getElementById('question-text');
const options = document.querySelector('.options')
const optionA = document.getElementById('option-a');
const optionB = document.getElementById('option-b');
const optionC = document.getElementById('option-c');
const choices = document.querySelector('.choice-buttons')
const choiceA = document.getElementById('choice-a');
const choiceB = document.getElementById('choice-b');
const choiceC = document.getElementById('choice-c');
const announcementMessage = document.getElementById('announcement');
const next = document.getElementById('next-btn');
const usedQuestions = [];

let score = 0

startButton.addEventListener('click', () => {
    playGame(quizData, usedQuestions)
});

function playGame(quizData, usedQuestions) {
    startScreen.classList.add('hidden');
    inGameScreen.classList.remove('hidden');

    let correctAnswer; // Move the correctAnswer declaration outside of playNextRound

    function playNextRound() {
        announcementMessage.innerText = '';
        next.classList.add('hidden');
        if (usedQuestions.length < quizData.length) {
            let question = getRandomQuestion(quizData, usedQuestions);
            announcementMessage.classList.remove('green-text');
            announcementMessage.classList.remove('red-text');
            questionText.innerHTML = question.question;
            optionA.innerHTML = question.answers[0];
            optionB.innerHTML = question.answers[1];
            optionC.innerHTML = question.answers[2];

            correctAnswer = question.correct; // Assign correctAnswer here

            // Remove previous click event listeners before adding new ones
            choiceA.removeEventListener('click', handleChoiceA);
            choiceB.removeEventListener('click', handleChoiceB);
            choiceC.removeEventListener('click', handleChoiceC);

            // Add new event listeners
            choiceA.addEventListener('click', handleChoiceA);
            choiceB.addEventListener('click', handleChoiceB);
            choiceC.addEventListener('click', handleChoiceC);
        } else {
            questionText.classList.add('hidden');
            options.classList.add('hidden')
            choices.classList.add('hidden')
            
            announcementMessage.classList.remove('green-text');
            announcementMessage.classList.remove('red-text');
            announcementMessage.innerText = `Your score is ${score}! Reload the web page if you would like to restart.`;
        }
    }

    function handleChoiceA() {
        checkAnswer(0, correctAnswer);
    }

    function handleChoiceB() {
        checkAnswer(1, correctAnswer);
    }

    function handleChoiceC() {
        checkAnswer(2, correctAnswer);
    }

    next.addEventListener('click', playNextRound);
    playNextRound();
}

function getRandomQuestion(quizData, usedQuestions) {
    const remainingQuestions = quizData.filter((_, index) => !usedQuestions.includes(index));
    const randomIndex = Math.floor(Math.random() * remainingQuestions.length);
    const selectedQuestion = remainingQuestions[randomIndex];
    usedQuestions.push(quizData.indexOf(selectedQuestion));
    return selectedQuestion;
}

function checkAnswer(chosenIndex, correctIndex) {
    const options = ['A', 'B', 'C']
    if (chosenIndex == correctIndex) {
        announcementMessage.classList.add('green-text')
        announcementMessage.innerText = 'Correct!'
        score += 1
    } else {
        announcementMessage.classList.add('red-text')
        announcementMessage.innerText = `Incorrect, the answer was ${options[correctIndex]}`
    }
    next.classList.remove('hidden')
}

