const quotes = {
    "The Polar Express": "Just remember, the true spirit of Christmas lies in your heart.",
    "Laura Ingalls Wilder": "We are better throughout the year for having, in spirit, become a child again at Christmastime.",
    "Charles Dickens, A Christmas Carol": "A merry Christmas to everybody! A happy New Year to all the world! Hallo here! Whoop! Hallo!",
    "Gladys Bagg Taber": "Best of all are the decorations the grandchildren have made — fat little stars and rather crooked Santas, shaped out of dough and baked in the oven.",    
    "Harlan Miller": "I wish we could put up some of the Christmas spirit in jars and open a jar of it every month.",
    "John J. Geddes": "Freshly cut Christmas trees smelling of stars and snow and pine resin—inhale deeply and fill your soul with wintry night.",
    "Rosie Thomas, Iris & Ruby": "Christmas works like glue, it keeps us all sticking together."
}

const generateBtn = document.getElementById('generate-btn');
const quoteContent = document.getElementById('quote-content');
const quoteAuthor = document.getElementById('author');
const authors = Object.keys(quotes);

// Generate new Christmas quote
generateBtn.addEventListener("click", () => {
    let randomQuoteAuthor = authors[generateRandomIndex(authors)];
    let randomQuote = quotes[randomQuoteAuthor];
    quoteContent.innerText = '„' + randomQuote + '“';
    quoteAuthor.innerText = "– " + randomQuoteAuthor;
});

const generateRandomIndex = () => {
    return Math.floor(Math.random() * authors.length);
}