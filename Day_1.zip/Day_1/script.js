let giftsData = [];

const generateInputFields = () => {
    const numOfGifts = parseInt(document.getElementById('numOfGifts').value);

    if (!isNaN(numOfGifts) && numOfGifts > 0)
    {
        let inputFieldsHTML = '';

        for (let i = 0; i < numOfGifts; i++)
        {
            inputFieldsHTML += `
            <label for="width${i}">Gift ${i + 1} - Width:</label>
            <input type="number" id="width${i}" placeholder="Enter width" min="0">

            <label for="height${i}">Height:</label>
            <input type="number" id="height${i}" placeholder="Enter height" min="0">

            <label for="length${i}">Length:</label>
            <input type="number" id="length${i}" placeholder="Enter length" min="0"><br>
            `;
        }
        document.getElementById('giftInputs').innerHTML = inputFieldsHTML;
    }
    else {
        alert('Please enter a valid number of gifts.');
    }
}

const calculateResult = () => {
    giftsData = [];
    const numOfGifts = parseInt(document.getElementById('numOfGifts').value);

    for (let i = 0; i < numOfGifts; i++) {
        const width = parseFloat(document.getElementById(`width${i}`).value);
        const height = parseFloat(document.getElementById(`height${i}`).value);
        const length = parseFloat(document.getElementById(`length${i}`).value);

        if (!isNaN(width) && !isNaN(height) && !isNaN(length)) {
            const gift = { width, height, length };
            giftsData.push(gift);
        } else {
            alert(`Please enter valid dimensions for Gift ${i + 1}.`);
            return; // Exit the function if invalid dimensions are found
        }
    }
    updateResult();
}

const calculateWrappingPaperArea = (gifts) => {
    let totalArea = 0;

    for (const gift of gifts) {
        const sides = [
            gift.width * gift.height,
            gift.height * gift.length,
            gift.length * gift.width
        ];

        const surfaceArea = 2 * (sides[0] + sides[1] + sides[2]);

        totalArea += surfaceArea;
    }

    return totalArea;
}
           
const updateResult = () => {
    const totalArea = calculateWrappingPaperArea(giftsData);
    document.getElementById('totalArea').textContent = totalArea.toString();
}

// Enable user to press enter in order to submit data.
document.getElementById('numOfGifts').addEventListener('keyup', function (event) {
    if (event.key === 'Enter') {
        generateInputFields();
    }
});

document.getElementById('giftInputs').addEventListener('keyup', function (event) {
    if (event.key === 'Enter') {
        calculateResult();
    }
});

       
