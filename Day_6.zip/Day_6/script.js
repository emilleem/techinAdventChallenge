// Keys and values to simplify getting input.
const validInputOptions = {
    "ss": "Santa's sleigh (scissors)",
    "sg": "Snow globe (rock)",
    "gw": "Gift wrap (paper)" 
}

// Prompts user in the browser.
const userChoice = prompt(
    "Choose your weapon:\n" +
    "  1. Write 'SS' for 'Santa\'s sleigh'\n" +
    "  2. Write 'SG' for 'Snow globe'\n" +
    "  3. Write 'GW' for 'Gift wrap'\n"
  );

// Input validation
let validInput = { value: false };
validateUserInput(userChoice, validInputOptions, validInput);
// If input is valid, play game.
if (validInput.value) {
    playGame(validInputOptions, userChoice);
}

// Function to validate user input and display a warning message if it's invalid.
function validateUserInput(userChoice, inputOptions, validInput) {
    const lowercaseInput = userChoice.toLowerCase();
    if (Object.keys(inputOptions).includes(lowercaseInput)) {
        validInput.value = true;
    }
    else {
        // Create warning message.
        const warningMessage = document.createElement('div');
        warningMessage.style.color = 'red';
        warningMessage.textContent = "Invalid choice!";
    
        // Create a button that will refresh the page if clicked.
        const tryAgainButton = document.createElement('button');
        tryAgainButton.textContent = "Try again";
        tryAgainButton.addEventListener('click', () => {
            location.reload();
        })
        // Display the elements.
        document.body.appendChild(warningMessage);
        document.body.appendChild(tryAgainButton);
    }
}

function pickComputersChoice(choiceOptions) {
    return Object.keys(choiceOptions)[Math.floor(Math.random() * 3)];
}

function displayChoice(choice, title, validInputOptions) {
    const heading = document.createElement('h3');
    const txt = document.createElement('p');
    heading.textContent = title;
    txt.textContent = validInputOptions[choice];

    document.body.appendChild(heading);
    document.body.appendChild(txt);
}

function finishGame(computersChoice, userChoice) {
    const resultElement = document.createElement('h2');
    
    if (computersChoice === userChoice) {
        resultElement.textContent = "It's a tie!";
    } else {
        const winConditions = {
            'ss': { 'sg': 'You win!', 'gw': 'You lose! :(' },
            'sg': { 'ss': 'You lose! :(', 'gw': 'You win!' },
            'gw': { 'ss': 'You win!', 'sg': 'You lose! :(' }
        };

        resultElement.textContent = winConditions[computersChoice][userChoice];
        document.body.appendChild(resultElement);
    }
}

function playGame(validInputOptions, userChoice) {
    let computerChoice = pickComputersChoice(validInputOptions);
    displayChoice(userChoice, "Your choice was: ", validInputOptions);
    displayChoice(computerChoice, "Computer's choice is: ", validInputOptions);
    finishGame(computerChoice, userChoice);
}
