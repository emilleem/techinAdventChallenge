const cookieCountDisplay = document.getElementById('cookie-count')
const addButton = document.getElementById('add-btn')
const resetButton = document.createElement('button')
const crunchSound = new Audio('crunchy-bite.mp3')
let cookieCount = 0

addButton.addEventListener('click', () => {
    crunchSound.currentTime = 0
    if (cookieCount == 0) {
        resetButton.innerHTML = 'Reset Count'
        resetButton.classList.add('reset-button')
        document.body.appendChild(resetButton)
    }
    cookieCount += 1
    cookieCountDisplay.innerHTML = `${cookieCount}`
    crunchSound.play()
})

resetButton.addEventListener('click', () => {
    cookieCount = 0
    cookieCountDisplay.innerHTML = `${cookieCount}`
    document.body.removeChild(resetButton)
})