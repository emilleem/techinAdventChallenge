const reindeerNames = [];

// Function to generate one random name.
const generateReindeerName = () => {
  const names = ['Rudolph', 'Snowflake', 'Twinkle', 'Merry', 'Frosty', 'Pixie', 'Dasher', 'Dancer', 'Vixer'];
  const surnames = ['Candy Cane', 'Angel', 'Star', 'Snow', 'Bell', 'Orange'];

  const randomName = names[Math.floor(Math.random() * names.length)];
  const randomSurname = surnames[Math.floor(Math.random() * surnames.length)];
  return `${randomName} ${randomSurname}`;
}

// Function to generate and display names, used in the HTML code.
const generateAndDisplay = () => {
    generateUniqueNames();
    displayReindeerNames();
}

// Function to generate a collection of 5 unique names.
const generateUniqueNames = () => {
    reindeerNames.length = 0;
    while (reindeerNames.length < 5) {
        const newName = generateReindeerName();
        if (!reindeerNames.includes(newName)) {
        reindeerNames.push(newName);
    }
  }
}

// Function to display reindeer names.
const displayReindeerNames = () => {
    const reindeerList = document.getElementById('namesList');
    reindeerList.innerHTML = '';
    reindeerNames.forEach(name => {
        const listItem = document.createElement('li');
        listItem.textContent = name;
        reindeerList.appendChild(listItem);
    });
}

// Function to sort names.
const sortNames = () => {
    reindeerNames.sort();
    displayReindeerNames();
}