const days = document.getElementById('days')

const currentMonth = new Date().getMonth()
const currentDay = new Date().getDay()
const nextChristmasYear = new Date().getFullYear()

if (currentMonth == 12 && currentDay >= 25) {
    nextChristmasYear += 1
}
const christmasTime = new Date(`December 25 ${nextChristmasYear} 00:00:00`)

// Update Countdown Timer
function updateCountdownTimer() {
    const currentTime = new Date()
    const diffMilliseconds = christmasTime - currentTime
    const daysLeft = Math.floor(diffMilliseconds / 1000 / 60 / 60 / 24)

    days.innerHTML = daysLeft
}

setInterval(updateCountdownTimer, 1000)
